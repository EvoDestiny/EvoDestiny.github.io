/* Destiny —— 轻量交互层。Product 下拉菜单通过 CSS 悬停处理；
   此脚本补充：导航栏滚动状态、移动端菜单、滚动显现动画和定价切换。 */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* 固定导航栏：页面滚动超过 8px 后加上细边框和阴影 */
  var nav = $("#nav");
  var onScroll = function () { if (nav) nav.classList.toggle("scrolled", window.scrollY > 8); };
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  /* 移动端菜单 */
  var burger = $(".nav__burger");
  if (burger && nav) {
    burger.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      burger.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  /* Product 菜单：桌面端 CSS 悬停处理；触摸屏 / 小屏幕点击触发按钮时切换展开 */
  $$(".nav__item.has-menu").forEach(function (item) {
    var trigger = $(".nav__trigger", item);
    if (!trigger) return;
    trigger.addEventListener("click", function (e) {
      if (window.matchMedia("(max-width: 720px)").matches) {
        e.preventDefault();
        item.classList.toggle("show");
      }
    });
  });

  /* 滚动显现 */
  var reveals = $$(".reveal");
  if ("IntersectionObserver" in window && reveals.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("in"); });
  }

  /* 定价周期切换（月付 / 年付） */
  var toggle = $(".toggle");
  if (toggle) {
    var btns = $$("button", toggle);
    var setMode = function (mode) {
      btns.forEach(function (b) { b.classList.toggle("active", b.dataset.mode === mode); });
      $$(".amt[data-monthly]").forEach(function (amt) {
        amt.textContent = mode === "annual" ? amt.dataset.annual : amt.dataset.monthly;
      });
    };
    btns.forEach(function (b) { b.addEventListener("click", function () { setMode(b.dataset.mode); }); });
    setMode("monthly");
  }

  /* Destiny Work —— 循环播放的"Claude Code 在终端工作"动画。它把任务打入输入框，
     先进入纯"思考"阶段（spinner 循环切换趣味词汇，token 计数和耗时秒数随之上升），
     然后逐字符流式输出助手回复，执行 ⏺/⎿ 工具调用，停在"完成"行后循环到下一个示例任务。
     在输入框中输入自己的任务并点击 Run，会直接进入同一个循环。
     只有终端在屏幕内时才运行，整个周期约 35 秒，模拟一次简短的 Claude Code 会话。 */
  var form = $("#task-form");
  if (form) {
    var input = $("#task-input");
    var body  = $("#work-term .term__body");
    var term  = $("#work-term");
    var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // 每个示例都是一段脚本化会话，由若干步骤组成，步骤类型说明：
    //   {think} → 纯思考阶段：spinner 循环趣味词汇，暂不输出文字
    //   {say}   → 一条 ⏺ 消息行，像真实 CLI 那样逐字符流式输出
    //   {tool,res} → ⏺ Tool(args) 后跟一条 ⎿ 结果      {verb} → spinner 标签 + 停留（思考停顿）
    //   {plan}  → ⏺ 标题 + ⎿ 检查列表项               {done} → 完成 + 循环
    var SAMPLES = [
      { task: "add rate limiting to the public API", steps: [
        { think: true },
        { say: "I'll add token-bucket rate limiting to the public API. Let me read the routing code first." },
        { verb: "Exploring the repo" },
        { tool: "Read(src/api/routes.ts)", res: "Read 124 lines" },
        { tool: 'Search(pattern: "export function handler")', res: "Found 3 matches in 3 files" },
        { verb: "Reasoning about the approach" },
        { plan: "Here's my plan:", items: ["add a token-bucket limiter in src/api/rateLimit.ts", "apply it to the 3 public routes", "cover it with unit tests"] },
        { verb: "Writing the code" },
        { tool: "Write(src/api/rateLimit.ts)", res: "Created src/api/rateLimit.ts with 42 additions", diff: [
          { n: "1", k: "add", t: "export function rateLimit(max = 60, windowMs = 60000) {" },
          { n: "2", k: "add", t: "  const hits = new Map();" },
          { n: "3", k: "add", t: "  return (req, res, next) => {" },
          { n: "4", k: "add", t: "    const now = Date.now();" },
          { n: "5", k: "add", t: "    const recent = (hits.get(req.ip) || []).filter(t => now - t < windowMs);" }
        ] },
        { tool: "Update(src/api/routes.ts)", res: "Updated src/api/routes.ts with 6 additions and 1 removal", diff: [
          { n: "11", k: "ctx", t: 'import { listItems } from "./handlers";' },
          { n: "12", k: "add", t: 'import { rateLimit } from "./rateLimit";' },
          { n: "13", k: "ctx", t: "" },
          { n: "14", k: "del", t: 'router.get("/v1/items", listItems);' },
          { n: "15", k: "add", t: 'router.get("/v1/items", rateLimit(), listItems);' }
        ] },
        { tool: "Write(test/rateLimit.test.ts)", res: "Created test/rateLimit.test.ts with 58 additions", diff: [
          { n: "1", k: "add", t: 'import request from "supertest";' },
          { n: "2", k: "add", t: 'import { app } from "../src/app";' },
          { n: "3", k: "add", t: "" },
          { n: "4", k: "add", t: 'test("blocks the 61st hit in a window", async () => {' },
          { n: "5", k: "add", t: "  for (let i = 0; i < 60; i++) await request(app).get(\"/v1/items\");" }
        ] },
        { verb: "Running the test suite" },
        { tool: "Bash(npm test)", res: "12 passed in 3.4s" },
        { say: "All green — opening a pull request." },
        { tool: "Bash(gh pr create)", res: "PR #142 · 3 files changed, +106 −2" },
        { done: true }
      ] },
      { task: "fix the flaky checkout test", steps: [
        { think: true },
        { say: "Let me reproduce the flaky checkout test before I change anything." },
        { verb: "Investigating" },
        { tool: "Bash(npm test -- checkout --runs 10)", res: "failed 2 / 10 runs" },
        { tool: "Read(test/checkout.test.ts)", res: "Read 88 lines" },
        { tool: "Read(src/checkout/cart.ts)", res: "Read 142 lines" },
        { verb: "Tracing the race condition" },
        { say: "It races on an unawaited timer. I'll make the wait deterministic." },
        { tool: "Update(test/checkout.test.ts)", res: "Updated test/checkout.test.ts with 9 additions and 5 removals", diff: [
          { n: "42", k: "del", t: "  setTimeout(() => cart.checkout(), 0);" },
          { n: "42", k: "add", t: "  await cart.checkout();" },
          { n: "43", k: "del", t: '  expect(cart.state).toBe("done");' },
          { n: "43", k: "add", t: '  await waitFor(() => expect(cart.state).toBe("done"));' }
        ] },
        { tool: "Update(src/checkout/cart.ts)", res: "Updated src/checkout/cart.ts with 3 additions and 1 removal", diff: [
          { n: "88", k: "ctx", t: "  async checkout() {" },
          { n: "89", k: "del", t: "    this.flush();" },
          { n: "89", k: "add", t: "    await this.flush();" }
        ] },
        { verb: "Re-running 20× to confirm" },
        { tool: "Bash(npm test -- checkout --runs 20)", res: "20 / 20 passed" },
        { say: "Stable now — opening a pull request." },
        { tool: "Bash(gh pr create)", res: "PR #143 · 2 files changed, +12 −6" },
        { done: true }
      ] },
      { task: "add a dark mode toggle", steps: [
        { think: true },
        { say: "I'll add a dark mode toggle with a saved preference. Let me read the theme setup first." },
        { verb: "Exploring the repo" },
        { tool: "Read(src/theme/ThemeProvider.tsx)", res: "Read 64 lines" },
        { tool: 'Search(pattern: "prefers-color-scheme")', res: "Found 1 match" },
        { verb: "Designing the change" },
        { plan: "Here's my plan:", items: ["add a useColorScheme() hook", "add the toggle to the header", "persist the choice to localStorage"] },
        { verb: "Writing the code" },
        { tool: "Write(src/theme/useColorScheme.ts)", res: "Created src/theme/useColorScheme.ts with 28 additions", diff: [
          { n: "1", k: "add", t: 'import { useEffect, useState } from "react";' },
          { n: "2", k: "add", t: "" },
          { n: "3", k: "add", t: "export function useColorScheme() {" },
          { n: "4", k: "add", t: "  const [theme, setTheme] = useState(() =>" },
          { n: "5", k: "add", t: '    localStorage.getItem("theme") || "system");' }
        ] },
        { tool: "Update(src/components/Header.tsx)", res: "Updated src/components/Header.tsx with 14 additions and 2 removals", diff: [
          { n: "18", k: "ctx", t: "  return (" },
          { n: "19", k: "del", t: '    <header className="bar">' },
          { n: "19", k: "add", t: '    <header className="bar" data-theme={theme}>' },
          { n: "20", k: "add", t: "      <ThemeToggle onChange={setTheme} />" }
        ] },
        { tool: "Write(test/useColorScheme.test.ts)", res: "Created test/useColorScheme.test.ts with 31 additions", diff: [
          { n: "1", k: "add", t: 'import { renderHook, act } from "@testing-library/react";' },
          { n: "2", k: "add", t: 'import { useColorScheme } from "../src/theme/useColorScheme";' },
          { n: "3", k: "add", t: "" },
          { n: "4", k: "add", t: 'test("persists the chosen theme", () => {' },
          { n: "5", k: "add", t: "  const { result } = renderHook(() => useColorScheme());" }
        ] },
        { verb: "Running the test suite" },
        { tool: "Bash(npm test)", res: "9 passed in 2.6s" },
        { say: "Done — opening a pull request." },
        { tool: "Bash(gh pr create)", res: "PR #144 · 3 files changed, +73 −2" },
        { done: true }
      ] }
    ];
    var genericSteps = function (task) {
      var w = (task.split(/\s+/)[0] || "task");
      return [
        { think: true },
        { say: "I'll handle “" + task + "”. Let me read the code first." },
        { verb: "Exploring the repo" },
        { tool: "Read(src/index.ts)", res: "Read 96 lines" },
        { tool: 'Search(pattern: "' + w + '")', res: "Found 4 matches" },
        { verb: "Reasoning about the approach" },
        { plan: "Here's my plan:", items: ["map the files this touches", "make the change", "add tests", "run the checks"] },
        { verb: "Writing the code" },
        { tool: "Update(src/index.ts)", res: "Updated src/index.ts with 24 additions and 3 removals", diff: [
          { n: "7", k: "ctx", t: "export function main() {" },
          { n: "8", k: "del", t: "  run();" },
          { n: "8", k: "add", t: "  run({ " + w + ": true });" },
          { n: "9", k: "add", t: "  report();" }
        ] },
        { tool: "Write(test/index.test.ts)", res: "Created test/index.test.ts with 40 additions", diff: [
          { n: "1", k: "add", t: 'import { main } from "../src/index";' },
          { n: "2", k: "add", t: "" },
          { n: "3", k: "add", t: 'test("' + w + '", () => {' },
          { n: "4", k: "add", t: "  expect(main()).toBeDefined();" }
        ] },
        { verb: "Running the test suite" },
        { tool: "Bash(npm test)", res: "9 passed in 2.7s" },
        { say: "All green. Opening a pull request." },
        { tool: "Bash(gh pr create)", res: "PR #142 · 3 files changed, +64 −3" },
        { done: true }
      ];
    };

    var SPIN = ["✶", "✸", "✻", "✺", "✹", "✷"];
    // spinner 循环的趣味动名词，模拟真实 CLI 的纯思考阶段
    var THINK = ["Thinking", "Pondering", "Cogitating", "Ruminating", "Noodling", "Percolating",
                 "Simmering", "Deliberating", "Mulling", "Puzzling", "Untangling", "Synthesizing",
                 "Considering", "Reasoning", "Conjuring", "Marinating"];
    var timers = [], spinTimer = null, rotTimer = null, idx = 0, started = false;
    var tokIn = 0, tokOut = 0, t0 = 0, spin = 0, label = "", statusEl = null;
    // 当前模型正在做什么，token 计数只在符合实际的时机变动：
    //   "gen"  → 正在生成推理 / 计划    → ↓ 输出上升
    //   "type" → 正在流式输出回复       → ↓ 输出随文字上升（逐字符处理）
    //   "wait" → 正在读 / 运行工具 / 空闲 → 两者暂停，结果返回时 ↑ 跳升
    var phase = "wait";
    var kfmt = function (n) { return n >= 1000 ? (n / 1000).toFixed(1) + "k" : String(n); };
    // 工具结果反馈给模型：读 / 搜索增加 ↑（输入）计数；写入增加 ↓（输出）计数
    var bumpTok = function (res) {
      var m;
      if ((m = res.match(/Read\s+(\d+)/)))         { tokIn  += parseInt(m[1], 10) * 11 + 120; }
      else if (/Found/.test(res))                  { tokIn  += 240 + Math.floor(Math.random() * 220); }
      else if (/passed|failed|runs/.test(res))     { tokIn  += 380 + Math.floor(Math.random() * 320); }
      else if (/PR\s*#/.test(res))                 { tokIn  += 140; }
      if ((m = res.match(/(\d+)\s+additions?/)))    { tokOut += parseInt(m[1], 10) * 8 + 60; }   // 写入的代码
    };

    var after = function (ms, fn) { var id = setTimeout(fn, ms); timers.push(id); return id; };
    var clearAll = function () { timers.forEach(clearTimeout); timers = []; if (spinTimer) { clearInterval(spinTimer); spinTimer = null; } if (rotTimer) { clearInterval(rotTimer); rotTimer = null; } };
    var el = function (cls) { var d = document.createElement("div"); if (cls) d.className = cls; return d; };
    var scrollDown = function () { body.scrollTop = body.scrollHeight; };
    var put = function (node) { if (statusEl && statusEl.parentNode === body) body.insertBefore(node, statusEl); else body.appendChild(node); scrollDown(); return node; };
    var spanLine = function (parts, cls) { var d = el(cls); parts.forEach(function (p) { var s = document.createElement("span"); if (p.c) s.className = p.c; s.textContent = p.t; d.appendChild(s); }); return put(d); };
    var tree = function (t) { return spanLine([{ t: "⎿  " + t }], "t-tree"); };
    var bullet = function (t) { return spanLine([{ c: "t-bullet", t: "⏺" }, { t: " " + t }]); };
    var toolLine = function (call) {                    // ⏺ Read(src/api/routes.ts) —— 参数显示为暗琥珀色
      var m = call.match(/^([A-Za-z]+)\((.*)\)$/);
      if (!m) return bullet(call);
      return spanLine([{ c: "t-bullet", t: "⏺" }, { t: " " + m[1] + "(" }, { c: "arg", t: m[2] }, { t: ")" }], "t-tool");
    };
    // 一条 ⏺ 助手消息行，文字逐字符流式输出，末尾带光标
    var typeBullet = function (text, done) {
      var d = el();
      var b = document.createElement("span"); b.className = "t-bullet"; b.textContent = "⏺";
      var t = document.createElement("span"); t.textContent = " ";
      var cur = document.createElement("span"); cur.className = "type-cursor";
      d.appendChild(b); d.appendChild(t); d.appendChild(cur); put(d);
      var i = 0;
      var tick = function () {
        if (i <= text.length) {
          t.textContent = " " + text.slice(0, i);
          if (i > 0) tokOut += 1 + Math.floor(Math.random() * 3);   // 输出随可见回复增长
          i++; scrollDown(); after(24, tick);
        }
        else { if (cur.parentNode) cur.parentNode.removeChild(cur); done(); }
      };
      tick();
    };
    // 简易 JS/TS 着色器，让 diff 代码像真实编辑器一样——关键字、字符串、数字、
    // 注释和函数名各有独立颜色。输出前对 HTML 特殊字符转义。
    var KW = /^(import|from|export|default|function|return|const|let|var|async|await|if|else|for|while|do|new|class|extends|of|in|typeof|void|true|false|null|undefined|this)$/;
    var esc = function (s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); };
    var highlight = function (code) {
      var out = "", i = 0, n = code.length;
      var push = function (cls, txt) { out += cls ? '<span class="' + cls + '">' + esc(txt) + "</span>" : esc(txt); };
      while (i < n) {
        var c = code[i];
        if (c === "/" && code[i + 1] === "/") { push("tk-com", code.slice(i)); break; }       // 行注释
        if (c === '"' || c === "'" || c === "`") {                                              // 字符串字面量
          var j = i + 1; while (j < n && code[j] !== c) { if (code[j] === "\\") j++; j++; }
          j = Math.min(j + 1, n); push("tk-str", code.slice(i, j)); i = j; continue;
        }
        if (c >= "0" && c <= "9") {                                                             // 数字
          var k = i + 1; while (k < n && /[0-9.]/.test(code[k])) k++;
          push("tk-num", code.slice(i, k)); i = k; continue;
        }
        if (/[A-Za-z_$]/.test(c)) {                                                             // 标识符 / 关键字 / 函数调用
          var e = i + 1; while (e < n && /[\w$]/.test(code[e])) e++;
          var word = code.slice(i, e), p = e; while (p < n && code[p] === " ") p++;
          push(KW.test(word) ? "tk-key" : code[p] === "(" ? "tk-fn" : null, word); i = e; continue;
        }
        push("tk-punct", c); i++;                                                               // 标点符号
      }
      return out;
    };
    // unified diff 中的一行：行号栏 + ± 符号 + 语法高亮代码
    var diffLine = function (ln) {
      var row = ln.k === "add" ? " row-add" : ln.k === "del" ? " row-del" : " row-ctx";
      var d = el("t-diff" + row);
      var num = document.createElement("span"); num.className = "ln"; num.textContent = ("     " + (ln.n || "")).slice(-5) + " ";
      var sym = document.createElement("span"); sym.className = ln.k; sym.textContent = ln.k === "add" ? "+ " : ln.k === "del" ? "- " : "  ";
      var code = document.createElement("span"); code.className = "code"; code.innerHTML = highlight(ln.t || "");
      d.appendChild(num); d.appendChild(sym); d.appendChild(code); return put(d);
    };

    var renderStatus = function () {
      if (!statusEl) return;
      var secs = Math.max(1, Math.round((performance.now() - t0) / 1000));
      statusEl.innerHTML = "";
      var sp = document.createElement("span"); sp.className = "t-spin"; sp.textContent = SPIN[spin];
      var lab = document.createElement("span"); lab.textContent = " " + label + "… ";
      var meta = document.createElement("span"); meta.className = "t-dim"; meta.textContent = "(" + secs + "s · ↑ " + kfmt(tokIn) + " · ↓ " + kfmt(tokOut) + " tokens · esc to interrupt)";
      statusEl.appendChild(sp); statusEl.appendChild(lab); statusEl.appendChild(meta);
      scrollDown();
    };
    var startStatus = function (lab) {
      label = lab;
      if (!statusEl) { statusEl = el("t-run"); body.appendChild(statusEl); }
      renderStatus();
      if (!spinTimer) spinTimer = setInterval(function () {
        spin = (spin + 1) % SPIN.length;
        if (phase === "gen") tokOut += 7 + Math.floor(Math.random() * 16);   // 只在生成阶段上升
        renderStatus();
      }, 130);
    };
    var setLabel = function (lab) { label = lab; renderStatus(); };
    var stopStatus = function () { if (spinTimer) { clearInterval(spinTimer); spinTimer = null; } if (statusEl && statusEl.parentNode) statusEl.parentNode.removeChild(statusEl); statusEl = null; };

    var welcomeBox = function () {
      var d = el("t-wb");
      d.innerHTML = '<div class="w-title">✻ Welcome to Destiny Code</div><div class="w-sub">/help for commands · /status for status</div><div class="w-sub">cwd: ~/project</div>';
      body.appendChild(d);
    };
    var typeBox = function (task, done) {
      var box = el("t-box");
      var chev = document.createElement("span"); chev.className = "chev"; chev.textContent = ">";
      var ph = document.createElement("span"); ph.className = "ph";
      var cur = document.createElement("span"); cur.className = "type-cursor";
      box.appendChild(chev); box.appendChild(ph); box.appendChild(cur); put(box);
      var i = 0;
      var tick = function () {
        if (i <= task.length) { ph.textContent = task.slice(0, i); i++; after(44, tick); }
        else { after(520, function () { if (cur.parentNode) cur.parentNode.removeChild(cur); done(); }); }
      };
      tick();
    };

    var walk = function (steps, i) {
      if (i >= steps.length) return;
      var s = steps[i];
      var next = function (ms) { after(ms, function () { walk(steps, i + 1); }); };
      if (s.think) {                                    // 纯思考阶段：循环趣味词汇，暂不输出文字
        phase = "gen";                                   // 正在推理 → ↓ 输出上升
        var dur = s.ms || 3200, r = 0;
        setLabel(THINK[0]);
        if (rotTimer) clearInterval(rotTimer);
        rotTimer = setInterval(function () { r = (r + 1) % THINK.length; setLabel(THINK[r]); }, 1300);
        after(dur, function () { if (rotTimer) { clearInterval(rotTimer); rotTimer = null; } walk(steps, i + 1); });
      }
      else if (s.verb) { phase = "gen"; setLabel(s.verb); next(s.ms || 2100); }
      else if (s.say) { phase = "type"; typeBullet(s.say, function () { phase = "wait"; next(s.ms || 800); }); }
      else if (s.plan) {
        phase = "gen";                                   // 生成计划文字 → ↓ 输出上升
        bullet(s.plan);
        s.items.forEach(function (it, k) { after(520 * (k + 1), function () { tree(it); }); });
        next(520 * s.items.length + 950);
      }
      else if (s.tool) {
        phase = "wait";                                  // 正在读 / 运行工具 → 计数暂停，结果返回时 ↑ 跳升
        toolLine(s.tool);
        after(680, function () {
          tree(s.res); bumpTok(s.res);
          if (s.diff) s.diff.forEach(function (ln, k) { after(120 * (k + 1), function () { diffLine(ln); }); });
        });
        next(s.diff ? 680 + 120 * s.diff.length + 1250 : 2050);
      }
      else if (s.done) {
        var secs = Math.max(1, Math.round((performance.now() - t0) / 1000));
        stopStatus();
        spanLine([{ c: "t-done", t: "● done · ↑ " + kfmt(tokIn) + " · ↓ " + kfmt(tokOut) + " tokens · " + secs + "s · esc to clear" }]);
        after(4200, function () { idx = (idx + 1) % SAMPLES.length; run(SAMPLES[idx].task, SAMPLES[idx].steps); });   // 循环
      }
    };

    var run = function (task, steps) {
      clearAll(); stopStatus(); body.innerHTML = "";
      // 一轮对话开始时系统提示 + 任务已在上下文中，所以 ↑ 从一个小基数开始；↓ 从 0 开始
      tokIn = 620 + Math.floor(Math.random() * 380); tokOut = 0; phase = "wait";
      t0 = performance.now(); spin = 0;
      welcomeBox();
      if (reduce) {                                   // 减少动画 → 直接呈现最终状态，不循环
        var b = el("t-box"); b.innerHTML = '<span class="chev">&gt;</span>'; var p = document.createElement("span"); p.className = "ph"; p.textContent = " " + task; b.appendChild(p); body.appendChild(b);
        (steps || genericSteps(task)).forEach(function (s) {
          if (s.say) bullet(s.say);
          else if (s.tool) { toolLine(s.tool); tree(s.res); if (s.diff) s.diff.forEach(diffLine); }
          else if (s.plan) { bullet(s.plan); s.items.forEach(tree); }
        });
        spanLine([{ c: "t-done", t: "● done · ↑ 9.4k · ↓ 2.6k tokens · 31s · esc to clear" }]);
        return;
      }
      typeBox(task, function () { startStatus("Working"); walk(steps || genericSteps(task), 0); });
    };

    var startLoop = function () { if (started) return; started = true; idx = 0; run(SAMPLES[0].task, SAMPLES[0].steps); };
    var stopLoop  = function () { started = false; clearAll(); stopStatus(); };

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      started = true;
      var task = input.value.trim();
      run(task || input.getAttribute("placeholder"), task ? genericSteps(task) : SAMPLES[0].steps);
    });

    if ("IntersectionObserver" in window) {            // 只在终端可见时播放动画
      new IntersectionObserver(function (ents) {
        ents.forEach(function (en) { if (en.isIntersecting) startLoop(); else stopLoop(); });
      }, { threshold: 0.25 }).observe(term);
    } else { startLoop(); }
  }

  /* 数字滚动计数 —— 元素进入视口时从 0 缓动到 data-count 目标值，带前后缀 */
  var counters = $$("[data-count]");
  if (counters.length) {
    var prefersReduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };   // easeOutCubic：先快后慢
    var runCount = function (node) {
      var target = parseFloat(node.getAttribute("data-count")) || 0;
      var prefix = node.getAttribute("data-prefix") || "";
      var suffix = node.getAttribute("data-suffix") || "";
      if (prefersReduce) { node.textContent = prefix + target + suffix; return; }
      var dur = 1400, t0 = performance.now();
      var frame = function (now) {
        var p = Math.min(1, (now - t0) / dur);
        node.textContent = prefix + Math.round(target * easeOut(p)) + suffix;
        if (p < 1) requestAnimationFrame(frame);
      };
      requestAnimationFrame(frame);
    };
    if ("IntersectionObserver" in window) {
      var cio = new IntersectionObserver(function (ents) {
        ents.forEach(function (en) { if (en.isIntersecting) { runCount(en.target); cio.unobserve(en.target); } });
      }, { threshold: 0.4 });
      counters.forEach(function (c) { cio.observe(c); });
    } else {
      counters.forEach(runCount);
    }
  }

  /* 页脚年份 */
  $$("[data-year]").forEach(function (el) { el.textContent = "2026"; });
})();
